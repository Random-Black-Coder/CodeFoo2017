package com.codefoo.yahkeefdavis.codefooapp;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Created by Yahkeef Davis on 3/17/2017.
 */

public class WebViewActivity extends AppCompatActivity
{
    //class variables
    WebView webView;
    ProgressBar bar;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        webView  = (WebView) findViewById(R.id.webView);
        bar      = (ProgressBar) findViewById(R.id.progressBar2);
        textView = (TextView) findViewById(R.id.Web_textView);
        webView.setWebViewClient(new myWebClient());
        webView.getSettings().setJavaScriptEnabled(true);

        //get url from extra content
        Bundle bundle = getIntent().getExtras();

        //load url
        webView.loadUrl(bundle.getString("url"));
    }

    public class myWebClient extends WebViewClient
    {
        //makes the loading animation and background text invisible when page is finished loading
        @Override
        public void onPageFinished(WebView view, String url)
        {
            super.onPageFinished(view, url);
            bar.setVisibility(View.GONE);
            textView.setVisibility(View.GONE);
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon)
        {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url)
        {
            return super.shouldOverrideUrlLoading(view, url);
        }
    }

    //allow user to go back
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if((keyCode==KeyEvent.KEYCODE_BACK) && webView.canGoBack())
        {
            webView.goBack();
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }
}