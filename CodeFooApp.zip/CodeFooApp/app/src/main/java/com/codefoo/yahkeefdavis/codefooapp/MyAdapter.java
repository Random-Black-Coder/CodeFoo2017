package com.codefoo.yahkeefdavis.codefooapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Yahkeef Davis on 3/10/2017.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>
{
    //class variables
    private List<Card> listCards;
    private Context context;

    public MyAdapter(List<Card> list, Context context)
    {
        this.listCards = list;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout1, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position)
    {
        final Card cards = listCards.get(position);
        holder.text.setText(cards.getHeadLine());
        holder.image.setImageDrawable(cards.getThumbnail());

        //sets button that starts the WebViewActivity whenever a card is tapped by user
        holder.cardView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(context, WebViewActivity.class);
                intent.putExtra("url", cards.getWebLink());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return listCards.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        public TextView text;
        public ImageView image;
        public CardView cardView;

        public ViewHolder(View itemView)
        {
            super(itemView);

            text  = (TextView) itemView.findViewById(R.id.Headline);
            image = (ImageView) itemView.findViewById(R.id.Thumbnail);
            cardView = (CardView) itemView.findViewById(R.id.card_layout1);
        }
    }
}
