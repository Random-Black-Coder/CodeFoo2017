package com.codefoo.yahkeefdavis.codefooapp;

import android.graphics.drawable.Drawable;

/**
 * Created by Yahkeef Davis on 3/10/2017.
 */

public class Card {

    //class variables
    private String headLine;   //the article title
    private Drawable thumbnail;//the thumbnail for each article
    private String webLink;    //the link to the each article's content

    public Card(String headLine, Drawable thumbnail, String webLink) {
        this.headLine = headLine;
        this.thumbnail = thumbnail;
        this.webLink = webLink;
    }

    public String getHeadLine() {
        return headLine;
    }

    public Drawable getThumbnail() {
        return thumbnail;
    }

    public String getWebLink() {
        return webLink;
    }
}
