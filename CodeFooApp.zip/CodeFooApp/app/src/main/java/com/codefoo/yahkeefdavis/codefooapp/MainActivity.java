package com.codefoo.yahkeefdavis.codefooapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img1;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img10;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img2;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img3;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img4;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img5;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img6;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img7;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img8;
import static com.codefoo.yahkeefdavis.codefooapp.R.drawable.img9;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h0;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h1;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h2;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h3;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h4;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h5;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h6;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h7;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h8;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.h9;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url0;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url1;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url2;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url3;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url4;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url5;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url6;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url7;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url8;
import static com.codefoo.yahkeefdavis.codefooapp.R.string.url9;

public class MainActivity extends AppCompatActivity
{
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<Card> listCards;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listCards = new ArrayList<>();

        //for every article
        for (int i = 0; i < 10; i++)
        {
            //new card object
            Card card;

            //picks a specific article with its respective headline, thumbnail and url
            switch(i)
            {
               case 0:
                   card = new Card(getString(h0), getDrawable(img1), getString(url0));
                   listCards.add(card);
               case 1:
                   card = new Card(getString(h1), getDrawable(img2), getString(url1));
                   listCards.add(card);
               case 2:
                   card = new Card(getString(h2), getDrawable(img3), getString(url2) );
                   listCards.add(card);
               case 3:
                   card = new Card(getString(h3), getDrawable(img4), getString(url3));
                   listCards.add(card);
               case 4:
                   card = new Card(getString(h4), getDrawable(img5), getString(url4));
                   listCards.add(card);
               case 5:
                   card = new Card(getString(h5), getDrawable(img6), getString(url5));
                   listCards.add(card);
               case 6:
                   card = new Card(getString(h6), getDrawable(img7), getString(url6));
                   listCards.add(card);
               case 7:
                   card = new Card(getString(h7), getDrawable(img8), getString(url7));
                   listCards.add(card);
               case 8:
                   card = new Card(getString(h8), getDrawable(img9), getString(url8));
                   listCards.add(card);
               case 9:
                   card = new Card(getString(h9), getDrawable(img10), getString(url9));
                   listCards.add(card);
               }
        }
        //instantiate & set the adapter
        adapter = new MyAdapter(listCards,this);
        recyclerView.setAdapter(adapter);
    }
}
